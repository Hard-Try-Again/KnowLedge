## Tomcat 操作

### Tomcat 安装

1、解压压缩文件

> 【注意】不要有中文路径

![image-20201204095825295](Pictures\image-20201204095825295.png)

2、效果如下

![image-20201204100135535](Pictures\image-20201204100135535.png)

### Tomcat 运行

1、移动到tomcat安装路径下，双击进入

![image-20201204100603144](Pictures\image-20201204100603144.png)

2、进入bin目录

![image-20201204100702009](Pictures\image-20201204100702009.png)

3、双击 `startup.bat` 启动 `Tomcat`

> 【注意】区别于 `startup.sh` ，此脚本用于 `Linux` 下 `Tomcat` 的启动，建议打开文件扩展名方便查看
>
> ```
> 查看 -> 勾选文件扩展名
> ```

![image-20201204101054741](Pictures\image-20201204101054741.png)

> 双击之后稍等片刻，会弹窗下面的窗口

4、出现图中显示毫秒值的字样说明启动成功

![image-20201204101556218](Pictures\image-20201204101556218.png)

### Tomcat 运行失败原因

> 如果一闪而过，说明没有配置 `JAVA_HOME` 环境变量

1、选择此电脑中的属性并打开

![image-20201204102023399](Pictures\image-20201204102023399.png)

2、点击高级系统设置

![image-20201204102515418](Pictures\image-20201204102515418.png)

3、选择高级下面的环境变量

![image-20201204102613087](Pictures\image-20201204102613087.png)

4、在系统变量下点击新建

![image-20201204102723837](Pictures\image-20201204102723837.png)

5、输入变量名并点击浏览目录

```
JAVA_HOME
```

![image-20201204102848860](Pictures\image-20201204102848860.png)

6、找到 `JDK` 在系统中的位置并选中点击确定

![image-20201204103045459](Pictures\image-20201204103045459.png)

7、配置好变量名和变量值后点击确定

![image-20201204103132731](Pictures\image-20201204103132731.png)

8、此时我们发现系统变量中已经有了JAVA_HOME，点击确定

![image-20201204103228156](Pictures\image-20201204103228156.png)

9、点击确定

![image-20201204103330881](Pictures\image-20201204103330881.png)

10、此时环境变量已经配置好，重新点击 `startup.bat` 就能成功打开 `Tomcat` 服务器软件

![image-20201204103611413](Pictures\image-20201204103611413.png)

### Tomcat 测试访问

打开 Tomcat 服务器软件后在浏览器的网址栏中输入下面的网址，能跳转到 Tomcat 主页说明访问成功

```http
http://localhost:8080
```

![image-20201204104023440](Pictures\image-20201204104023440.png)

### Tomcat 停止

在 `Tomcat` 的 `bin` 目录下点击 `shutdown.bat` 即可

![image-20201204104324604](Pictures\image-20201204104324604.png)

### Tomcat 中导入前端静态项目

>我们可以将一些写好的 `HTML`、`CSS`、`JavaScript`、图片等静态资源组成的项目通过 `Tomcat` 服务器使用浏览器对其进行访问，这里我使用了一个最简单的测试项目，同学们可自行选择自己写好的页面进行测试，只需要把项目所在文件夹整个复制到 `Tomcat` 的 `webapps` 目录下即可

1、启动 `Tomcat` 服务器

2、进入到 `Tomcat` 安装路径下的 `webapps` 文件路径

![image-20201204104642511](Pictures\image-20201204104642511.png)

3、将前端页面所在文件夹直接复制过来即可

![image-20201204105051865](Pictures\image-20201204105051865.png)

>进入此项目发现只有一个 `test.html` 页面
>
>![image-20201204105406963](Pictures\image-20201204105406963.png)
>
>内容如下
>
>![image-20201204105510799](Pictures\image-20201204105510799.png)

4、在浏览器中输入下面格式的网址即可访问到对应的项目页面

```
格式：
http://localhost:8080/项目名/资源名

例如：
http://localhost:8080/project/test.html
```

5、效果如下

![image-20201204105631103](Pictures\image-20201204105631103.png)